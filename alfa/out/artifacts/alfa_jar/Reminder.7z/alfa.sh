java -jar alfa.jar
